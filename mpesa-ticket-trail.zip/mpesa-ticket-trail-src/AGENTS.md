<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Payments go through the provider switch in `src/lib/payments.server.ts` (`PAYMENT_PROVIDER` env), never a payment API called straight from a route or component. Reason: the site must work with a payment service that collects on the owner's behalf (no own Paybill/Till) and still be able to switch to a direct connection later.
- The payment provider's reference for an order is stored in `orders.checkout_request_id`, and a ticket is only issued after `markPaid` re-verifies the charge with the provider and the amount matches the order. Reason: webhook/callback bodies are a trigger, not proof of payment.
- Any callback endpoint the payment provider calls must verify the caller's shared secret before touching an order, and must be reachable over public HTTPS. Reason: the endpoint is unauthenticated by design and localhost callbacks are rejected outright.
