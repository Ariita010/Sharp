import { EVENT } from "./event";

async function admin() {
  return (await import("@/integrations/supabase/client.server")).supabaseAdmin;
}

async function sendSms(to: string, message: string) {
  const username = process.env["AFRICASTALKING_USERNAME"];
  const apiKey = process.env["AFRICASTALKING_API_KEY"];
  if (!username || !apiKey) {
    console.warn("SMS not sent: Africa's Talking keys missing");
    return false;
  }
  const host = username === "sandbox" ? "api.sandbox.africastalking.com" : "api.africastalking.com";
  const res = await fetch(`https://${host}/version1/messaging`, {
    method: "POST",
    headers: { apiKey, Accept: "application/json", "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username, to: `+${to}`, message }),
  });
  if (!res.ok) {
    console.error(`SMS failed [${res.status}]: ${await res.text()}`);
    return false;
  }
  return true;
}

/** Mark order paid (once) and send the confirmation SMS. */
export async function markPaid(checkoutRequestId: string, receipt?: string | null, chargedAmount?: number | null) {
  const db = await admin();
  const { data: existing } = await db
    .from("orders")
    .select("id, status, amount")
    .eq("checkout_request_id", checkoutRequestId)
    .maybeSingle();
  if (!existing || existing.status === "paid") return;
  // Only hand out a ticket when the amount actually collected matches what we asked for.
  if (typeof chargedAmount === "number" && chargedAmount !== existing.amount) {
    console.error(
      `Amount mismatch on ${checkoutRequestId}: collected ${chargedAmount}, expected ${existing.amount}`,
    );
    return;
  }
  const { data: order } = await db
    .from("orders")
    .update({ status: "paid", paid_at: new Date().toISOString(), mpesa_receipt: receipt ?? null })
    .eq("id", existing.id)
    .neq("status", "paid")
    .select()
    .maybeSingle();
  if (!order) return;
  const ok = await sendSms(
    order.phone,
    `Hi ${order.full_name.split(" ")[0]}, payment confirmed! ${order.quantity} ticket(s) for ${EVENT.name}, ${EVENT.date} at ${EVENT.venue}. Ticket code: ${order.ticket_code}.${receipt ? ` M-Pesa ref: ${receipt}.` : ""}`,
  );
  if (ok) await db.from("orders").update({ sms_sent: true }).eq("id", order.id);
}

export async function markFailed(checkoutRequestId: string, reason?: string) {
  const db = await admin();
  await db
    .from("orders")
    .update({ status: "failed", failure_reason: reason ?? null })
    .eq("checkout_request_id", checkoutRequestId)
    .eq("status", "pending");
}
