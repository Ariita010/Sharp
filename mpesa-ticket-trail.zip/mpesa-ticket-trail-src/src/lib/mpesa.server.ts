// M-Pesa Daraja STK push helpers. Server-only.
// Defaults to Safaricom's public sandbox shortcode/passkey until real ones are set.
const SANDBOX_SHORTCODE = "174379";
const SANDBOX_PASSKEY = "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919";

function cfg() {
  const env = process.env["MPESA_ENV"] === "production" ? "production" : "sandbox";
  return {
    base: env === "production" ? "https://api.safaricom.co.ke" : "https://sandbox.safaricom.co.ke",
    key: process.env["MPESA_CONSUMER_KEY"],
    secret: process.env["MPESA_CONSUMER_SECRET"],
    shortcode: process.env["MPESA_SHORTCODE"] || SANDBOX_SHORTCODE,
    passkey: process.env["MPESA_PASSKEY"] || SANDBOX_PASSKEY,
    // "CustomerPayBillOnline" for Paybill, "CustomerBuyGoodsOnline" for Till
    txType: process.env["MPESA_TRANSACTION_TYPE"] || "CustomerPayBillOnline",
    partyB: process.env["MPESA_PARTY_B"] || process.env["MPESA_SHORTCODE"] || SANDBOX_SHORTCODE,
  };
}

async function token(c: ReturnType<typeof cfg>) {
  if (!c.key || !c.secret) throw new Error("M-Pesa keys are not configured yet.");
  const res = await fetch(`${c.base}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${btoa(`${c.key}:${c.secret}`)}` },
  });
  if (!res.ok) throw new Error(`M-Pesa auth failed [${res.status}]: ${await res.text()}`);
  return ((await res.json()) as { access_token: string }).access_token;
}

function stamp() {
  const d = new Date(Date.now() + 3 * 3600 * 1000); // Nairobi time
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}${p(d.getUTCHours())}${p(d.getUTCMinutes())}${p(d.getUTCSeconds())}`;
}

export async function stkPush(opts: { phone: string; amount: number; reference: string; callbackUrl: string }) {
  const c = cfg();
  const t = await token(c);
  const ts = stamp();
  const res = await fetch(`${c.base}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      BusinessShortCode: c.shortcode,
      Password: btoa(c.shortcode + c.passkey + ts),
      Timestamp: ts,
      TransactionType: c.txType,
      Amount: opts.amount,
      PartyA: opts.phone,
      PartyB: c.partyB,
      PhoneNumber: opts.phone,
      CallBackURL: opts.callbackUrl,
      AccountReference: opts.reference.slice(0, 12),
      TransactionDesc: "Event tickets",
    }),
  });
  const body = (await res.json()) as { CheckoutRequestID?: string; ResponseCode?: string; errorMessage?: string; CustomerMessage?: string };
  if (!res.ok || body.ResponseCode !== "0" || !body.CheckoutRequestID) {
    throw new Error(body.errorMessage || body.CustomerMessage || `M-Pesa request failed [${res.status}]`);
  }
  return body.CheckoutRequestID;
}

/** Returns "paid" | "failed" | "pending" */
export async function stkQuery(checkoutRequestId: string): Promise<{ state: "paid" | "failed" | "pending"; reason?: string | undefined }> {
  const c = cfg();
  const t = await token(c);
  const ts = stamp();
  const res = await fetch(`${c.base}/mpesa/stkpushquery/v1/query`, {
    method: "POST",
    headers: { Authorization: `Bearer ${t}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      BusinessShortCode: c.shortcode,
      Password: btoa(c.shortcode + c.passkey + ts),
      Timestamp: ts,
      CheckoutRequestID: checkoutRequestId,
    }),
  });
  const body = (await res.json()) as { ResultCode?: string; ResultDesc?: string; errorCode?: string };
  if (body.ResultCode === undefined) return { state: "pending" }; // still processing
  if (String(body.ResultCode) === "0") return { state: "paid" };
  return { state: "failed", reason: body.ResultDesc };
}
