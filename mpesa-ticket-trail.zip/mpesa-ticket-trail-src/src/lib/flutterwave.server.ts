// Flutterwave M-Pesa collection.
//
// The owner has no Safaricom Paybill or Buy Goods/Till, so he cannot send the STK prompt from his own
// shortcode. Flutterwave sends the prompt for him and settles the money into his own bank/MoMo account.
//
// Secrets (Project Settings -> Secrets):
//   FLW_SECRET_KEY  - Flutterwave's secret key (test_... / live_...) from API Keys in the dashboard.
//   FLW_VERIFY_HASH - the same "verify hash" you paste into Settings -> Webhooks; we compare it against
//                     the `verif-hash` header on every callback.
//
// Set PAYMENT_PROVIDER=mpesa to talk to Safaricom Daraja directly instead (needs your own shortcode).

const BASE = "https://api.flutterwave.com/v3";

export type PaymentState = "paid" | "failed" | "pending";

export type FlwVerification = {
  state: PaymentState;
  receipt?: string | null;
  reason?: string;
  amount?: number | null;
  currency?: string | null;
};

function secretKey(): string {
  const key = process.env["FLW_SECRET_KEY"];
  if (!key) throw new Error("Payments aren't set up yet. Please try again in a little while.");
  return key;
}

/** Sends the M-Pesa prompt to `phone`. `reference` must be unique per payment attempt. */
export async function flwStartPayment(opts: {
  phone: string;
  amount: number;
  email: string;
  reference: string;
}): Promise<string> {
  const res = await fetch(`${BASE}/charges?type=mpesa`, {
    method: "POST",
    headers: { Authorization: `Bearer ${secretKey()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      phone_number: opts.phone,
      amount: opts.amount,
      currency: "KES",
      email: opts.email,
      tx_ref: opts.reference,
    }),
  });
  const json = (await res.json().catch(() => null)) as { status?: string; message?: string } | null;
  if (!res.ok || json?.status !== "success") {
    throw new Error(json?.message || `Payment request failed (${res.status})`);
  }
  return opts.reference;
}

/** Asks Flutterwave directly what became of a charge — the webhook body alone is never trusted. */
export async function flwVerify(reference: string): Promise<FlwVerification> {
  try {
    const res = await fetch(
      `${BASE}/transactions/verify_by_reference?tx_ref=${encodeURIComponent(reference)}`,
      { headers: { Authorization: `Bearer ${secretKey()}` } },
    );
    const json = (await res.json().catch(() => null)) as {
      status?: string;
      data?: { status?: string; flw_ref?: string; processor_response?: string; amount?: number; currency?: string };
    } | null;
    const data = json?.data;
    if (!res.ok || !data) return { state: "pending" };

    const status = String(data.status ?? "").toLowerCase();
    if (status === "successful" || status === "completed") {
      return {
        state: "paid",
        receipt: data.flw_ref ? String(data.flw_ref) : null,
        amount: typeof data.amount === "number" ? data.amount : null,
        currency: data.currency ?? null,
      };
    }
    if (status === "failed" || status === "cancelled" || status === "reversed") {
      return { state: "failed", reason: data.processor_response || "Payment failed" };
    }
    return { state: "pending" };
  } catch (e) {
    console.error("Flutterwave verification failed", e);
    return { state: "pending" };
  }
}

/** Constant-time string compare without Buffer (this code runs on the edge runtime). */
function sameSecret(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/** True only when the callback carries the verify hash we also pasted into Flutterwave's dashboard. */
export function flwWebhookAuthed(headerValue: string | null): boolean {
  const expected = process.env["FLW_VERIFY_HASH"];
  if (!expected) return false;
  return !!headerValue && sameSecret(headerValue, expected);
}
