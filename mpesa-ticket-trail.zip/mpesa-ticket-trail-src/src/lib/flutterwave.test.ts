import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { flwVerify, flwWebhookAuthed } from "@/lib/flutterwave.server";

describe("flwWebhookAuthed", () => {
  const original = process.env["FLW_VERIFY_HASH"];
  afterEach(() => {
    if (original === undefined) delete process.env["FLW_VERIFY_HASH"];
    else process.env["FLW_VERIFY_HASH"] = original;
  });

  it("rejects every callback while no verify hash is configured", () => {
    delete process.env["FLW_VERIFY_HASH"];
    expect(flwWebhookAuthed("anything")).toBe(false);
  });

  it("rejects a missing, wrong or padded verify hash", () => {
    process.env["FLW_VERIFY_HASH"] = "s3cret-hash";
    expect(flwWebhookAuthed(null)).toBe(false);
    expect(flwWebhookAuthed("wrong-hash")).toBe(false);
    expect(flwWebhookAuthed("s3cret-hash!")).toBe(false);
  });

  it("accepts the exact verify hash Flutterwave sends back", () => {
    process.env["FLW_VERIFY_HASH"] = "s3cret-hash";
    expect(flwWebhookAuthed("s3cret-hash")).toBe(true);
  });
});

describe("flwVerify", () => {
  beforeEach(() => {
    process.env["FLW_SECRET_KEY"] = "FLW_TESTSECRETKEY_test";
  });
  afterEach(() => {
    vi.unstubAllGlobals();
    delete process.env["FLW_SECRET_KEY"];
  });

  function stubTransaction(status: string, extra: Record<string, unknown> = {}) {
    vi.stubGlobal(
      "fetch",
      vi.fn(
        async () =>
          new Response(JSON.stringify({ status: "success", data: { status, ...extra } }), { status: 200 }),
      ),
    );
  }

  it("counts a successful transaction as paid and keeps its reference", async () => {
    stubTransaction("successful", { flw_ref: "FLW-777", amount: 1000, currency: "KES" });
    expect(await flwVerify("order-1")).toEqual({
      state: "paid",
      receipt: "FLW-777",
      amount: 1000,
      currency: "KES",
    });
  });

  it("keeps a pending transaction pending", async () => {
    stubTransaction("pending");
    expect((await flwVerify("order-1")).state).toBe("pending");
  });

  it("reports a failed transaction with Flutterwave's reason", async () => {
    stubTransaction("failed", { processor_response: "Invalid Mobile Number" });
    const r = await flwVerify("order-1");
    expect(r.state).toBe("failed");
    expect(r.reason).toBe("Invalid Mobile Number");
  });

  it("stays pending when Flutterwave cannot be reached", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn(async () => {
        throw new Error("network down");
      }),
    );
    expect((await flwVerify("order-1")).state).toBe("pending");
  });
});
