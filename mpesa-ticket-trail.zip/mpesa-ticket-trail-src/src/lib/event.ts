// Event details shown on the site. Placeholder match name — replace with the real fixture.
export const EVENT = {
  name: "FC Bayern Munich vs Ajax FC",
  tagline: "FC Bayern Munich take on Ajax FC at Raila Odinga Stadium. Pay with M-Pesa, get your ticket instantly.",
  date: "Tuesday, 5 January 2027",
  time: "TBA",
  venue: "Raila Odinga Stadium, Nairobi",
  priceKes: 1000,
  maxPerOrder: 10,
};

/** True until the organiser sets a kickoff time. */
export const timeTba = (time: string = EVENT.time) => /^(tba|to be announced)$/i.test(time.trim());

/** "Tuesday, 5 January 2027" when kickoff is TBA, otherwise date + time. */
export function eventSchedule(date: string = EVENT.date, time: string = EVENT.time): string {
  return timeTba(time) ? date : `${date} · ${time}`;
}

/** Normalise Kenyan numbers (07.., 01.., +254.., 254..) to 2547XXXXXXXX. Returns null if invalid. */
export function normalizeKenyanPhone(input: string): string | null {
  const digits = input.replace(/[^\d]/g, "");
  let local: string;
  if (digits.startsWith("254")) local = digits.slice(3);
  else if (digits.startsWith("0")) local = digits.slice(1);
  else local = digits;
  if (!/^[17]\d{8}$/.test(local)) return null;
  return `254${local}`;
}

export function orderTotal(quantity: number): number {
  return quantity * EVENT.priceKes;
}
