import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";
import { EVENT, normalizeKenyanPhone, orderTotal } from "./event";

const orderInput = z.object({
  fullName: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(120),
  phone: z.string().trim().min(9).max(16),
  quantity: z.number().int().min(1).max(EVENT.maxPerOrder),
});

export const createOrder = createServerFn({ method: "POST" })
  .validator((d: unknown) => orderInput.parse(d))
  .handler(async ({ data }) => {
    const phone = normalizeKenyanPhone(data.phone);
    if (!phone) throw new Error("Enter a valid Safaricom number, e.g. 0712 345 678");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { startPayment } = await import("./payments.server");
    const amount = orderTotal(data.quantity);

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .insert({ full_name: data.fullName, email: data.email, phone, quantity: data.quantity, amount })
      .select("id, ticket_code")
      .single();
    if (error || !order) throw new Error("Could not create your order. Please try again.");

    const origin = new URL(getRequest().url).origin;
    try {
      const ref = await startPayment({
        phone,
        amount,
        email: data.email,
        reference: order.id,
        label: order.ticket_code,
        callbackUrl: `${origin}/api/public/mpesa/callback`,
      });
      await supabaseAdmin.from("orders").update({ checkout_request_id: ref }).eq("id", order.id);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "M-Pesa request failed";
      await supabaseAdmin.from("orders").update({ status: "failed", failure_reason: msg }).eq("id", order.id);
      throw new Error(msg);
    }
    return { orderId: order.id };
  });

export const getOrder = createServerFn({ method: "GET" })
  .validator((d: unknown) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const sel = "id, full_name, email, quantity, amount, status, ticket_code, mpesa_receipt, failure_reason, checkout_request_id, created_at";
    let { data: order } = await supabaseAdmin.from("orders").select(sel).eq("id", data.id).maybeSingle();
    if (!order) return null;

    // Fallback if the M-Pesa callback hasn't arrived: ask Safaricom directly.
    const ageMs = Date.now() - new Date(order.created_at).getTime();
    if (order.status === "pending" && order.checkout_request_id && ageMs > 15000) {
      const { checkPayment } = await import("./payments.server");
      const { markPaid, markFailed } = await import("./orders.server");
      try {
        const r = await checkPayment(order.checkout_request_id);
        if (r.state === "paid") await markPaid(order.checkout_request_id, r.receipt, r.amount);
        if (r.state === "failed") await markFailed(order.checkout_request_id, r.reason);
        if (r.state !== "pending") {
          ({ data: order } = await supabaseAdmin.from("orders").select(sel).eq("id", data.id).maybeSingle());
        }
      } catch (e) {
        console.error("STK query failed", e);
      }
    }
    if (!order) return null;
    const { checkout_request_id: _c, ...safe } = order;
    return safe;
  });
