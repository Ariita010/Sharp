// One payment layer, two providers.
//   flutterwave (default) - sends the M-Pesa prompt for us and settles into the owner's bank. No Paybill/Till needed.
//   mpesa                 - straight to Safaricom Daraja; only useful once the owner owns a shortcode.
//
// Whatever `startPayment` returns is stored in orders.checkout_request_id and used to look the payment
// up again, so both providers share one code path.

import { flwStartPayment, flwVerify, type PaymentState } from "./flutterwave.server";
import { stkQuery, stkPush } from "./mpesa.server";

export type Provider = "flutterwave" | "mpesa";

export function activeProvider(): Provider {
  return process.env["PAYMENT_PROVIDER"] === "mpesa" ? "mpesa" : "flutterwave";
}

export type PaymentResult = {
  state: PaymentState;
  receipt?: string | null;
  reason?: string | undefined;
  amount?: number | null;
};

/** Starts collecting money and returns the reference we keep on the order. */
export async function startPayment(opts: {
  phone: string;
  amount: number;
  email: string;
  reference: string;
  label: string;
  callbackUrl: string;
}): Promise<string> {
  if (activeProvider() === "mpesa") {
    return stkPush({
      phone: opts.phone,
      amount: opts.amount,
      reference: opts.label,
      callbackUrl: opts.callbackUrl,
    });
  }
  return flwStartPayment({
    phone: opts.phone,
    amount: opts.amount,
    email: opts.email,
    reference: opts.reference,
  });
}

/** Asks the provider what became of a payment we started. */
export async function checkPayment(ref: string): Promise<PaymentResult> {
  if (activeProvider() === "mpesa") {
    const r = await stkQuery(ref);
    return { state: r.state, receipt: null, reason: r.reason };
  }
  const r = await flwVerify(ref);
  return { state: r.state, receipt: r.receipt ?? null, reason: r.reason, amount: r.amount ?? null };
}
