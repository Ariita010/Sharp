import { describe, expect, it } from "vitest";
import { EVENT, eventSchedule, normalizeKenyanPhone, orderTotal, timeTba } from "./event";

describe("event details", () => {
  it("is FC Bayern Munich against Ajax FC", () => {
    expect(EVENT.name).toBe("FC Bayern Munich vs Ajax FC");
    expect(EVENT.tagline).toContain("Ajax FC");
  });

  it("is a football match at Raila Odinga Stadium on 5 January 2027", () => {
    expect(EVENT.venue).toBe("Raila Odinga Stadium, Nairobi");
    expect(EVENT.date).toBe("Tuesday, 5 January 2027");
    expect(timeTba()).toBe(true);
  });

  it("shows only the date while kickoff is TBA", () => {
    expect(eventSchedule("Tuesday, 5 January 2027", "TBA")).toBe("Tuesday, 5 January 2027");
    expect(eventSchedule("Tuesday, 5 January 2027", "3:00 PM")).toBe("Tuesday, 5 January 2027 · 3:00 PM");
  });
});

describe("normalizeKenyanPhone", () => {
  it("accepts 07 numbers", () => expect(normalizeKenyanPhone("0712 345 678")).toBe("254712345678"));
  it("accepts 01 numbers", () => expect(normalizeKenyanPhone("0110345678")).toBe("254110345678"));
  it("accepts +254 numbers", () => expect(normalizeKenyanPhone("+254712345678")).toBe("254712345678"));
  it("rejects short numbers", () => expect(normalizeKenyanPhone("07123")).toBeNull());
});

describe("orderTotal", () => {
  it("charges KES 1000 per ticket", () => expect(EVENT.priceKes).toBe(1000));
  it("multiplies ticket price by quantity", () => expect(orderTotal(3)).toBe(3000));
});
