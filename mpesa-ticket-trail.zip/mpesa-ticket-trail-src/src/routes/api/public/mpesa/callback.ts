import { createFileRoute } from "@tanstack/react-router";

// Safaricom posts STK results here. We only trust it to identify the CheckoutRequestID;
// a paid status is applied only to an existing pending order with that ID.
export const Route = createFileRoute("/api/public/mpesa/callback")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const body = (await request.json()) as {
            Body?: { stkCallback?: { CheckoutRequestID?: string; ResultCode?: number; ResultDesc?: string; CallbackMetadata?: { Item?: { Name: string; Value?: string | number }[] } } };
          };
          const cb = body.Body?.stkCallback;
          if (cb?.CheckoutRequestID) {
            const { markPaid, markFailed } = await import("@/lib/orders.server");
            if (cb.ResultCode === 0) {
              const receipt = cb.CallbackMetadata?.Item?.find((i) => i.Name === "MpesaReceiptNumber")?.Value;
              const paid = Number(cb.CallbackMetadata?.Item?.find((i) => i.Name === "Amount")?.Value);
              await markPaid(
                cb.CheckoutRequestID,
                receipt ? String(receipt) : null,
                Number.isFinite(paid) ? paid : null,
              );
            } else {
              await markFailed(cb.CheckoutRequestID, cb.ResultDesc);
            }
          }
        } catch (e) {
          console.error("M-Pesa callback error", e);
        }
        return Response.json({ ResultCode: 0, ResultDesc: "Accepted" });
      },
    },
  },
});
