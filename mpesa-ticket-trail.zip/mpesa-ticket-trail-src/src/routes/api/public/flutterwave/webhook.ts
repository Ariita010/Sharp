import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const payload = z.object({
  event: z.string(),
  data: z.object({
    tx_ref: z.string(),
    status: z.string(),
    flw_ref: z.string().nullish(),
    processor_response: z.string().nullish(),
  }),
});

// Flutterwave posts payment results here. The body is only a trigger: we re-check the charge with
// Flutterwave before handing out a ticket, so a forged or mistyped payload can't create one.
export const Route = createFileRoute("/api/public/flutterwave/webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { flwWebhookAuthed, flwVerify } = await import("@/lib/flutterwave.server");
        if (!flwWebhookAuthed(request.headers.get("verif-hash"))) {
          return Response.json({ error: "unauthorized" }, { status: 401 });
        }
        try {
          const body = payload.parse(await request.json());
          if (body.event === "charge.completed") {
            const { markPaid, markFailed } = await import("@/lib/orders.server");
            const status = body.data.status.toLowerCase();
            if (status === "successful" || status === "completed") {
              const check = await flwVerify(body.data.tx_ref);
              if (check.state === "paid") {
                await markPaid(body.data.tx_ref, check.receipt ?? body.data.flw_ref ?? null, check.amount);
              }
            } else if (status === "failed" || status === "cancelled") {
              await markFailed(body.data.tx_ref, body.data.processor_response ?? "Payment failed");
            }
          }
        } catch (e) {
          console.error("Flutterwave webhook error", e);
        }
        return Response.json({ status: "ok" });
      },
    },
  },
});
