import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useState } from "react";
import { toast } from "sonner";
import { Calendar, MapPin, Minus, Plus, Smartphone, Ticket } from "lucide-react";
import poster from "@/assets/bayern-ajax-poster.jpg";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { EVENT, eventSchedule, normalizeKenyanPhone, orderTotal, timeTba } from "@/lib/event";
import { createOrder } from "@/lib/orders.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: `${EVENT.name} — Buy football tickets with M-Pesa` },
      { name: "description", content: `${EVENT.date} at ${EVENT.venue}. Pay with M-Pesa and get your ticket instantly.` },
      { property: "og:title", content: `${EVENT.name} — Match tickets` },
      { property: "og:description", content: `${EVENT.date} at ${EVENT.venue}. Pay with M-Pesa.` },
    ],
  }),
  component: Index,
});

function Index() {
  const navigate = useNavigate();
  const submit = useServerFn(createOrder);
  const [qty, setQty] = useState(1);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ fullName: "", email: "", phone: "" });

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!normalizeKenyanPhone(form.phone)) { toast.error("Enter a valid Safaricom number, e.g. 0712 345 678"); return; }
    setBusy(true);
    try {
      const { orderId } = await submit({ data: { ...form, quantity: qty } });
      navigate({ to: "/ticket/$id", params: { id: orderId } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Payment request failed");
      setBusy(false);
    }
  };

  return (
    <main className="min-h-screen">
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-fade" />
        <div className="relative mx-auto grid max-w-5xl items-center gap-10 px-6 pb-16 pt-16 md:grid-cols-[minmax(0,1fr)_340px] md:pt-24">
          <div className="order-2 md:order-1">
            <p className="mb-4 inline-block rounded-full border border-primary/40 bg-background/40 px-3 py-1 text-xs uppercase tracking-widest text-primary">
              Tickets on sale
            </p>
            <h1 className="text-4xl font-extrabold leading-none md:text-6xl">{EVENT.name}</h1>
            <p className="mt-4 max-w-lg text-lg text-muted-foreground">{EVENT.tagline}</p>
            <div className="mt-6 flex flex-wrap gap-5 text-sm">
              <span className="flex items-center gap-2"><Calendar className="h-4 w-4 text-accent" />{eventSchedule()}</span>
              {timeTba() && <span className="flex items-center gap-2"><Ticket className="h-4 w-4 text-accent" />Kickoff time TBA</span>}
              <span className="flex items-center gap-2"><MapPin className="h-4 w-4 text-accent" />{EVENT.venue}</span>
            </div>
          </div>
          <div className="order-1 md:order-2">
            <img
              src={poster}
              alt={`${EVENT.name} match poster, ${EVENT.date} at ${EVENT.venue}`}
              className="mx-auto w-full max-w-[340px] rounded-3xl border border-primary/25 object-contain shadow-glow"
            />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-24">
        <form onSubmit={onSubmit} className="grid gap-8 rounded-3xl border bg-card p-6 shadow-glow md:grid-cols-[1fr_280px] md:p-10">
          <div className="space-y-5">
            <h2 className="text-2xl font-bold">Get your tickets</h2>
            <div className="space-y-2">
              <Label htmlFor="name">Full name</Label>
              <Input id="name" required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">M-Pesa phone number</Label>
              <Input id="phone" inputMode="tel" placeholder="0712 345 678" required value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
              <p className="text-xs text-muted-foreground">You'll get a payment prompt on this phone and your confirmation by SMS.</p>
            </div>
          </div>

          <div className="flex flex-col justify-between gap-6 rounded-2xl bg-secondary p-6">
            <div>
              <p className="text-sm text-muted-foreground">Regular ticket</p>
              <p className="font-display text-3xl font-bold">KES {EVENT.priceKes.toLocaleString()}</p>
              <div className="mt-5 flex items-center justify-between">
                <span className="text-sm">Quantity</span>
                <div className="flex items-center gap-3">
                  <Button type="button" size="icon" variant="outline" aria-label="Fewer" onClick={() => setQty(Math.max(1, qty - 1))}><Minus className="h-4 w-4" /></Button>
                  <span className="w-6 text-center font-semibold">{qty}</span>
                  <Button type="button" size="icon" variant="outline" aria-label="More" onClick={() => setQty(Math.min(EVENT.maxPerOrder, qty + 1))}><Plus className="h-4 w-4" /></Button>
                </div>
              </div>
            </div>
            <div>
              <div className="mb-4 flex justify-between border-t pt-4 font-semibold">
                <span>Total</span><span>KES {orderTotal(qty).toLocaleString()}</span>
              </div>
              <Button type="submit" size="lg" className="w-full" disabled={busy}>
                <Smartphone className="h-4 w-4" />{busy ? "Sending prompt…" : "Pay with M-Pesa"}
              </Button>
            </div>
          </div>
        </form>
      </section>
    </main>
  );
}
