import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EVENT, eventSchedule, timeTba } from "@/lib/event";
import { getOrder } from "@/lib/orders.functions";

const orderQuery = (id: string) =>
  queryOptions({
    queryKey: ["order", id],
    queryFn: () => getOrder({ data: { id } }),
    refetchInterval: (q) => (q.state.data?.status === "pending" ? 4000 : false),
  });

export const Route = createFileRoute("/ticket/$id")({
  head: () => ({
    meta: [
      { title: `Your ticket — ${EVENT.name}` },
      { name: "description", content: `Payment status and ticket for ${EVENT.name}.` },
      { property: "og:title", content: `Your ticket — ${EVENT.name}` },
      { property: "og:description", content: `Ticket for ${EVENT.name}.` },
    ],
  }),
  loader: ({ context, params }) => context.queryClient.ensureQueryData(orderQuery(params.id)),
  component: TicketPage,
});

function TicketPage() {
  const { id } = Route.useParams();
  const { data: order } = useSuspenseQuery(orderQuery(id));

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-16">
      <div className="w-full max-w-md rounded-3xl border bg-card p-8 text-center shadow-glow">
        {!order ? (
          <p>We couldn't find this order.</p>
        ) : order.status === "pending" ? (
          <>
            <Loader2 className="mx-auto h-12 w-12 animate-spin text-primary" />
            <h1 className="mt-5 text-2xl font-bold">Check your phone</h1>
            <p className="mt-2 text-muted-foreground">
              Enter your M-Pesa PIN to pay KES {order.amount.toLocaleString()}. This page updates on its own.
            </p>
          </>
        ) : order.status === "failed" ? (
          <>
            <XCircle className="mx-auto h-12 w-12 text-destructive" />
            <h1 className="mt-5 text-2xl font-bold">Payment didn't go through</h1>
            <p className="mt-2 text-muted-foreground">{order.failure_reason || "The request was cancelled or timed out."}</p>
            <Button asChild className="mt-6"><Link to="/">Try again</Link></Button>
          </>
        ) : (
          <>
            <CheckCircle2 className="mx-auto h-12 w-12 text-primary" />
            <h1 className="mt-5 text-2xl font-bold">You're in!</h1>
            <p className="mt-2 text-muted-foreground">A confirmation SMS is on its way.</p>
            <div className="mt-6 rounded-2xl border border-dashed border-primary/50 bg-secondary p-6 text-left">
              <p className="text-xs uppercase tracking-widest text-muted-foreground">{EVENT.name}</p>
              <p className="mt-1 font-display text-4xl font-extrabold tracking-wider text-accent">{order.ticket_code}</p>
              <dl className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div><dt className="text-muted-foreground">Name</dt><dd>{order.full_name}</dd></div>
                <div><dt className="text-muted-foreground">Tickets</dt><dd>{order.quantity}</dd></div>
                <div><dt className="text-muted-foreground">Date</dt><dd>{eventSchedule()}</dd></div>
                <div><dt className="text-muted-foreground">Venue</dt><dd>{EVENT.venue}</dd></div>
                <div><dt className="text-muted-foreground">Payment ref</dt><dd>{order.mpesa_receipt || "—"}</dd></div>
              </dl>
            </div>
            {timeTba() && (
              <p className="mt-4 text-xs text-muted-foreground">Kickoff time is still to be announced — we'll text and email you as soon as it's set.</p>
            )}
            <p className="mt-4 text-xs text-muted-foreground">Show this code at the gate. Bookmark this page to keep your ticket.</p>
          </>
        )}
      </div>
    </main>
  );
}
