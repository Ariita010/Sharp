# Roadmap

## Now
- [x] Ticket price KES 1,000 (owner-set 2026-10-30; was 500).
- [x] Payment provider switch built: Flutterwave M-Pesa by default, `PAYMENT_PROVIDER=mpesa` for a direct Safaricom connection. Webhook + tests in place.

## Waiting on owner
- [ ] Flutterwave account (unregistered-business route): needs ID, KRA PIN + certificate, address proof, payout bank/MoMo details, website URL. Then collect `FLW_SECRET_KEY` and `FLW_VERIFY_HASH` in a secure form.
- [ ] Africa's Talking username + API key for confirmation SMS.
- [ ] Kickoff time (currently TBA).
- [ ] Confirm poster use is cleared (State House emblem, club crests, player photos).
- [ ] Decide page wording: "Raila Odinga International Stadium at Talanta Sports City" and the poster's "tickets on sale from 5 November".

## Later
- [ ] Ticket emails — needs a domain the owner owns.
- [ ] Publish so payment confirmations reach the site (callback URL must be public HTTPS).
