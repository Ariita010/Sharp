# FC Bayern Munich vs Ajax FC — Ticket Site

A single-event ticket page: a buyer fills in their name, email, phone and ticket
count, pays by M-Pesa prompt, and gets a ticket code on screen plus a
confirmation text message.

- **Fixture:** FC Bayern Munich vs Ajax FC
- **Venue:** Raila Odinga Stadium, Nairobi
- **Date:** Tuesday, 5 January 2027 (kickoff time still to be announced)
- **Price:** KES 1,000 per ticket, up to 10 per order

## Stack

TanStack Start (React 19 + Vite 7), TypeScript, Tailwind CSS v4, shadcn/ui,
Vitest. Database and auth: Supabase (Lovable Cloud). Payments: Flutterwave
M-Pesa (default) or direct Safaricom Daraja. Texts: Africa's Talking.

## Setup

```sh
npm install          # or: bun install
cp .env.example .env # then fill in the values
npm run dev          # http://localhost:8080
```

Other scripts: `npm run build`, `npm run preview`, `npm run test`, `npm run lint`.

### Environment variables

Copy `.env.example` to `.env`. Nothing works without `SUPABASE_URL` and
`SUPABASE_PUBLISHABLE_KEY` (plus `VITE_` copies) — the site cannot save orders.
Payments need `FLW_SECRET_KEY` and `FLW_VERIFY_HASH`, or the `MPESA_*` set when
`PAYMENT_PROVIDER=mpesa`. Texts need `AFRICASTALKING_USERNAME` and
`AFRICASTALKING_API_KEY`. `.env` is git-ignored; never commit real keys.

### Database

`drizzle/migrations/0000_migration.sql` creates the `public.orders` table,
enables row-level security and grants access to `service_role` only — every
read and write goes through the server functions in `src/lib/orders.functions.ts`.
Apply it against your Supabase project before taking orders.

## How a payment flows

1. `createOrder` (server function) validates the input, normalises the Kenyan
   phone number, inserts an `orders` row, then asks the provider to send the
   M-Pesa prompt. The provider's reference for the attempt is stored in
   `orders.checkout_request_id`.
2. The provider calls back: `POST /api/public/flutterwave/webhook` (checks the
   `verif-hash` header against `FLW_VERIFY_HASH`) or
   `POST /api/public/mpesa/callback` for direct Daraja.
3. A callback is only a trigger. `markPaid` re-checks the charge with the
   provider and compares the collected amount with the order amount before
   handing out a ticket, then sends the confirmation text.
4. If no callback arrives, the ticket page polls `getOrder`, which asks the
   provider directly once the order is older than 15 seconds.

Callback endpoints must be reachable over public HTTPS, so they only fire once
the site is deployed — locally the polling path is what confirms payment.

## Where things live

| Path | What it does |
| --- | --- |
| `src/lib/event.ts` | Event name, date, venue, price, phone normalising, order total |
| `src/lib/payments.server.ts` | Provider switch: `flutterwave` or `mpesa` |
| `src/lib/flutterwave.server.ts` | Flutterwave charge, verification, webhook check |
| `src/lib/mpesa.server.ts` | Direct Safaricom Daraja STK push and query |
| `src/lib/orders.server.ts` | `markPaid` / `markFailed`, confirmation text |
| `src/lib/orders.functions.ts` | `createOrder` and `getOrder` server functions |
| `src/routes/index.tsx` | Home page and checkout form |
| `src/routes/ticket.$id.tsx` | Ticket page, polls until payment resolves |
| `src/routes/api/public/*` | Payment provider callbacks |

## Pushing to GitHub

```sh
git init
git add .
git commit -m "Initial ticket site"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo>.git
git push -u origin main
```

Create the empty repository on GitHub first, and don't replace the name with a
repo that already has history.

## Not wired up yet

- **Ticket emails** — the ticket code shows on screen and in the text message;
  email delivery needs a domain you own.
- **Kickoff time** — `EVENT.time` in `src/lib/event.ts` is `"TBA"`; the page
  shows a "kickoff time TBA" note until a real time is set.
- **Live money** — until Flutterwave's keys are in `.env`, no real payment can
  be taken.
